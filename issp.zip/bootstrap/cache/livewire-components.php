<?php return array (
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);