<nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
    <a href="<?php echo e(route('index')); ?>" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
        <h2 class="m-0 "><img src="<?php echo e(asset('images/logoTrans.png')); ?>" width="20%" class="m-3"alt=""></i>ISSP Nº 9112</h2>
    </a>
    <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav ms-auto p-4 p-lg-0">
            <a href="<?php echo e(route('index')); ?>" class="nav-item nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>">Home</a>
            <a href="<?php echo e(route('sobre-nosotros')); ?>"
                class="nav-item nav-link <?php echo e(request()->is('sobre-nosotros') ? 'active' : ''); ?>">Institución</a>
            <div class="nav-item dropdown">
                <a href="#"
                    class="nav-link dropdown-toggle <?php echo e(request()->is('carreras/sistemas') ? 'active' : (request()->is('carreras/robotica') ? 'active' : (request()->is('carreras/comercializacion') ? 'active' : ''))); ?>"
                    data-bs-toggle="dropdown">Carreras</a>
                <div class="dropdown-menu fade-down m-0">
                    <a href="<?php echo e(route('pages.carreras.comercializacion')); ?>" class="dropdown-item <?php echo e(request()->is('carreras/comercializacion') ? 'active' : ''); ?>">Comercialización</a>
                    <a href="<?php echo e(route('pages.carreras.robotica')); ?>" class="dropdown-item <?php echo e(request()->is('carreras/robotica') ? 'active' : ''); ?>">Robótica</a>
                    <a href="<?php echo e(route('pages.carreras.sistemas')); ?>"
                        class="dropdown-item <?php echo e(request()->is('carreras/sistemas') ? 'active' : ''); ?>">Sistemas</a>
                </div>
            </div>

            <a href="<?php echo e(route('contacto')); ?>"
                class="nav-item nav-link <?php echo e(request()->is('contacto') ? 'active' : ''); ?>">Contacto</a>
        </div>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary py-4 px-lg-5 d-block d-lg-block">CAMPUS<i
                class="fa fa-arrow-right ms-3"></i></a>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\issp\resources\views/livewire/navigation.blade.php ENDPATH**/ ?>